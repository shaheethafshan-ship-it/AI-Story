import os
from io import BytesIO
from datetime import datetime

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(
    page_title="AI Data Storytelling Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.block-container {padding-top: 1.4rem; padding-bottom: 2rem;}
[data-testid="stMetric"] {background: rgba(128,128,128,.08); padding: 14px 16px; border-radius: 12px;}
.story-card {padding: 16px 18px; border: 1px solid rgba(128,128,128,.25); border-radius: 12px; margin-bottom: 10px;}
.small-note {font-size: .88rem; opacity: .8;}
</style>
""", unsafe_allow_html=True)

st.title("📊 AI Data Storytelling Dashboard")
st.caption("Turn raw data into understandable patterns, charts, and data-backed stories.")

# --------------------------- Data utilities ---------------------------

def load_sample():
    path = os.path.join(os.path.dirname(__file__), "data", "sample_sales.csv")
    return pd.read_csv(path, parse_dates=["Order Date"])

def clean_column_names(df):
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df

def find_date_columns(df):
    found = []
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            found.append(col)
        elif df[col].dtype == "object":
            parsed = pd.to_datetime(df[col], errors="coerce")
            if len(df) and parsed.notna().mean() >= 0.75:
                found.append(col)
    return found

def coerce_dates(df, columns):
    df = df.copy()
    for col in columns:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    return df

def numeric_columns(df):
    return df.select_dtypes(include=np.number).columns.tolist()

def categorical_columns(df):
    return [c for c in df.columns if c not in numeric_columns(df)
            and not pd.api.types.is_datetime64_any_dtype(df[c])]

def money_fmt(value):
    if pd.isna(value):
        return "N/A"
    return f"{value:,.2f}"

def make_story(df, metric, category, date_col):
    """Create transparent, data-derived insights without requiring an external AI API."""
    stories = []
    if df.empty:
        return ["There are no rows to analyze. Upload a dataset containing data."]
    if metric and metric in df.columns and pd.api.types.is_numeric_dtype(df[metric]):
        s = pd.to_numeric(df[metric], errors="coerce").dropna()
        if len(s):
            total = s.sum()
            avg = s.mean()
            median = s.median()
            stories.append(
                f"**Overall picture:** `{metric}` totals **{total:,.2f}** across "
                f"{len(s):,} valid records. The average is **{avg:,.2f}** and the median is "
                f"**{median:,.2f}**."
            )
            if len(s) >= 4 and s.std(ddof=0) > 0:
                q1, q3 = s.quantile([.25, .75])
                high = s[s > q3].count()
                stories.append(
                    f"**Spread:** The middle 50% of `{metric}` values lie between "
                    f"**{q1:,.2f}** and **{q3:,.2f}**. {high:,} records are above the 75th percentile."
                )
    if category and category in df.columns and metric and metric in df.columns:
        grouped = df.groupby(category, dropna=False)[metric].sum().sort_values(ascending=False)
        grouped = grouped[grouped.index.notna()]
        if len(grouped):
            best_name, best_value = grouped.index[0], grouped.iloc[0]
            stories.append(
                f"**Category leader:** **{best_name}** has the highest total `{metric}` "
                f"(**{best_value:,.2f}**)."
            )
            if len(grouped) > 1:
                bottom_name, bottom_value = grouped.index[-1], grouped.iloc[-1]
                stories.append(
                    f"**Opportunity to investigate:** **{bottom_name}** has the lowest total "
                    f"`{metric}` (**{bottom_value:,.2f}**). Check volume, pricing, and data quality "
                    "before deciding what action to take."
                )
    if date_col and date_col in df.columns and metric and metric in df.columns:
        temp = df[[date_col, metric]].dropna().copy()
        if len(temp) >= 2:
            temp["Period"] = temp[date_col].dt.to_period("M").astype(str)
            monthly = temp.groupby("Period")[metric].sum().sort_index()
            if len(monthly) >= 2:
                first, last = monthly.iloc[0], monthly.iloc[-1]
                if first != 0:
                    pct = ((last - first) / abs(first)) * 100
                    direction = "increased" if last > first else "decreased" if last < first else "stayed level"
                    stories.append(
                        f"**Time trend:** Monthly `{metric}` {direction} from "
                        f"**{first:,.2f}** in {monthly.index[0]} to **{last:,.2f}** in "
                        f"{monthly.index[-1]} ({pct:+.1f}% from first to last month). "
                        "This compares endpoints and does not prove the cause of the change."
                    )
    missing = int(df.isna().sum().sum())
    if missing:
        stories.append(
            f"**Data quality:** There are **{missing:,} missing cells** in the current dataset. "
            "Consider cleaning or documenting missing values before making decisions."
        )
    if not stories:
        stories.append("Choose a numeric measure and, if available, a category or date column to generate more specific insights.")
    return stories

def to_csv_bytes(df):
    return df.to_csv(index=False).encode("utf-8")

# --------------------------- Sidebar ---------------------------

with st.sidebar:
    st.header("⚙️ Data & controls")
    source = st.radio("Choose data source", ["Use sample dataset", "Upload a CSV"], index=0)
    uploaded = None
    if source == "Upload a CSV":
        uploaded = st.file_uploader("Upload CSV file", type=["csv"])
    st.divider()
    st.markdown("**Dashboard guide**")
    st.write("1. Load sample data or upload a CSV.")
    st.write("2. Select a measure, category, and date field.")
    st.write("3. Use filters to focus the analysis.")
    st.write("4. Review charts and generated stories.")
    st.caption("Insights are generated from dataset statistics. They are not causal claims.")

# --------------------------- Load data ---------------------------

try:
    if source == "Upload a CSV":
        if uploaded is None:
            st.info("Upload a CSV file in the sidebar, or choose the sample dataset to explore the dashboard.")
            st.stop()
        raw_df = pd.read_csv(uploaded)
    else:
        raw_df = load_sample()
except Exception as exc:
    st.error(f"Could not load the data: {exc}")
    st.stop()

raw_df = clean_column_names(raw_df)
if raw_df.empty:
    st.warning("The dataset has no rows.")
    st.stop()
if len(raw_df.columns) == 0:
    st.error("The CSV has no columns.")
    st.stop()

date_candidates = find_date_columns(raw_df)
raw_df = coerce_dates(raw_df, date_candidates)
nums = numeric_columns(raw_df)
cats = categorical_columns(raw_df)
dates = find_date_columns(raw_df)

st.subheader("Dataset overview")
a, b, c, d = st.columns(4)
a.metric("Rows", f"{len(raw_df):,}")
b.metric("Columns", f"{len(raw_df.columns):,}")
c.metric("Numeric columns", f"{len(nums):,}")
d.metric("Missing cells", f"{int(raw_df.isna().sum().sum()):,}")

with st.expander("Preview data", expanded=False):
    st.dataframe(raw_df.head(100), use_container_width=True)
    st.download_button("Download loaded dataset", to_csv_bytes(raw_df), "loaded_dataset.csv", "text/csv")

if not nums:
    st.warning("No numeric columns were found. Add numeric data (for example, sales, score, quantity, or cost) to use metric-based charts.")
    st.dataframe(raw_df.head(20), use_container_width=True)
    st.stop()

# Pick sensible defaults
preferred_metric = next((x for x in ["Sales", "Revenue", "Profit", "Amount", "Score", "Quantity"] if x in nums), nums[0])
preferred_category = next((x for x in ["Region", "Category", "Product", "Segment", "Department"] if x in cats), (cats[0] if cats else "(None)"))
preferred_date = next((x for x in ["Order Date", "Date", "Timestamp"] if x in dates), (dates[0] if dates else "(None)"))

st.sidebar.subheader("Analysis settings")
metric = st.sidebar.selectbox("Numeric measure", nums, index=nums.index(preferred_metric))
category_options = ["(None)"] + cats
category = st.sidebar.selectbox("Category / group", category_options, index=category_options.index(preferred_category) if preferred_category in category_options else 0)
date_options = ["(None)"] + dates
date_col = st.sidebar.selectbox("Date / time field", date_options, index=date_options.index(preferred_date) if preferred_date in date_options else 0)

df = raw_df.copy()

# Add filters for categorical columns with manageable cardinality
filter_cols = [col for col in cats if 1 < df[col].nunique(dropna=True) <= 50]
if filter_cols:
    st.sidebar.subheader("Filters")
    for col in filter_cols[:5]:
        values = sorted(df[col].dropna().astype(str).unique().tolist())
        selected = st.sidebar.multiselect(f"{col}", values, default=values, key=f"filter_{col}")
        df = df[df[col].astype(str).isin(selected) | df[col].isna()]

if date_col != "(None)" and date_col in df.columns:
    valid_dates = df[date_col].dropna()
    if not valid_dates.empty:
        min_d, max_d = valid_dates.min().date(), valid_dates.max().date()
        date_range = st.sidebar.date_input("Date range", value=(min_d, max_d), min_value=min_d, max_value=max_d)
        if isinstance(date_range, tuple) and len(date_range) == 2:
            start_d, end_d = date_range
            df = df[df[date_col].isna() | df[date_col].dt.date.between(start_d, end_d)]

if df.empty:
    st.warning("No records match the selected filters. Change or clear the filters.")
    st.stop()

# --------------------------- KPI row ---------------------------

st.divider()
st.subheader("Key performance indicators")
total = pd.to_numeric(df[metric], errors="coerce").sum()
mean_val = pd.to_numeric(df[metric], errors="coerce").mean()
median_val = pd.to_numeric(df[metric], errors="coerce").median()
valid_count = int(pd.to_numeric(df[metric], errors="coerce").notna().sum())
k1, k2, k3, k4 = st.columns(4)
k1.metric(f"Total {metric}", f"{total:,.2f}")
k2.metric(f"Average {metric}", f"{mean_val:,.2f}" if pd.notna(mean_val) else "N/A")
k3.metric(f"Median {metric}", f"{median_val:,.2f}" if pd.notna(median_val) else "N/A")
k4.metric("Valid measure records", f"{valid_count:,}")

# --------------------------- Charts ---------------------------

left, right = st.columns(2)
with left:
    st.subheader(f"{metric} distribution")
    hist_df = df[[metric]].dropna()
    if not hist_df.empty:
        fig = px.histogram(hist_df, x=metric, nbins=25, marginal="box",
                           title=f"How {metric} values are distributed")
        fig.update_layout(height=390, margin=dict(l=10, r=10, t=55, b=10))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No valid numeric values for this measure.")

with right:
    st.subheader(f"{metric} by category")
    if category != "(None)" and category in df.columns:
        grouped = df.groupby(category, dropna=False)[metric].sum().reset_index()
        grouped[category] = grouped[category].fillna("(Missing)").astype(str)
        grouped = grouped.sort_values(metric, ascending=False).head(15)
        fig = px.bar(grouped, x=category, y=metric, color=category,
                     title=f"Top groups by total {metric}", text_auto=".2s")
        fig.update_layout(height=390, showlegend=False, margin=dict(l=10, r=10, t=55, b=10))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Select a category column in the sidebar to compare groups.")

left2, right2 = st.columns(2)
with left2:
    st.subheader("Trend over time")
    if date_col != "(None)" and date_col in df.columns:
        trend = df[[date_col, metric]].dropna().copy()
        if not trend.empty:
            trend["Month"] = trend[date_col].dt.to_period("M").dt.to_timestamp()
            trend = trend.groupby("Month", as_index=False)[metric].sum().sort_values("Month")
            fig = px.line(trend, x="Month", y=metric, markers=True,
                          title=f"Monthly total {metric}")
            fig.update_layout(height=380, margin=dict(l=10, r=10, t=55, b=10))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No valid date/measure pairs are available.")
    else:
        st.info("Select a date column in the sidebar to display trends.")

with right2:
    st.subheader("Measure by group")
    if category != "(None)" and category in df.columns:
        box_df = df[[category, metric]].dropna()
        if not box_df.empty:
            box_df[category] = box_df[category].astype(str)
            top_cats = box_df[category].value_counts().head(10).index
            box_df = box_df[box_df[category].isin(top_cats)]
            fig = px.box(box_df, x=category, y=metric, points="outliers",
                         title=f"Variation in {metric} across groups")
            fig.update_layout(height=380, margin=dict(l=10, r=10, t=55, b=10))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No valid category/measure pairs are available.")
    else:
        st.info("Select a category column to compare variation across groups.")

# --------------------------- Correlation ---------------------------

if len(nums) >= 2:
    st.divider()
    st.subheader("Correlation explorer")
    corr = df[nums].corr(numeric_only=True)
    fig = px.imshow(corr, text_auto=".2f", aspect="auto",
                    color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
                    title="Correlation between numeric columns")
    fig.update_layout(height=max(350, min(650, 45 * len(nums))))
    st.plotly_chart(fig, use_container_width=True)
    st.caption("Correlation describes association, not causation. Relationships may be influenced by other variables.")

# --------------------------- Story / insights ---------------------------

st.divider()
st.subheader("🧠 Generated data story")
st.caption("These rule-based insights are generated automatically from the selected data. They do not require an API key.")
stories = make_story(df, metric, None if category == "(None)" else category,
                     None if date_col == "(None)" else date_col)
for story in stories:
    st.markdown(f'<div class="story-card">{story}</div>', unsafe_allow_html=True)

# Basic outlier scan with IQR
measure_series = pd.to_numeric(df[metric], errors="coerce").dropna()
if len(measure_series) >= 4:
    q1, q3 = measure_series.quantile([.25, .75])
    iqr = q3 - q1
    if iqr > 0:
        outliers = df[(pd.to_numeric(df[metric], errors="coerce") < q1 - 1.5 * iqr) |
                      (pd.to_numeric(df[metric], errors="coerce") > q3 + 1.5 * iqr)]
        with st.expander(f"Potential outliers ({len(outliers):,})"):
            st.write("Records outside the 1.5×IQR range. These may be valid rare events; inspect them before removing anything.")
            st.dataframe(outliers, use_container_width=True)
            st.download_button("Download potential outliers", to_csv_bytes(outliers), "potential_outliers.csv", "text/csv")

# --------------------------- Export ---------------------------

st.divider()
st.subheader("Export")
summary = pd.DataFrame({
    "Metric": ["Selected measure", "Rows after filters", "Total", "Average", "Median", "Missing cells"],
    "Value": [metric, len(df), total, mean_val, median_val, int(df.isna().sum().sum())]
})
csv_report = summary.to_csv(index=False).encode("utf-8")
st.download_button("Download KPI summary (CSV)", csv_report, "dashboard_summary.csv", "text/csv")
st.download_button("Download filtered data (CSV)", to_csv_bytes(df), "filtered_data.csv", "text/csv")

report_lines = [
    "AI DATA STORYTELLING DASHBOARD — SUMMARY",
    f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
    f"Rows after filters: {len(df)}",
    f"Columns: {len(df.columns)}",
    f"Selected measure: {metric}",
    f"Total: {total:,.2f}",
    f"Average: {mean_val:,.2f}" if pd.notna(mean_val) else "Average: N/A",
    f"Median: {median_val:,.2f}" if pd.notna(median_val) else "Median: N/A",
    "",
    "GENERATED INSIGHTS",
]
for s in stories:
    import re
    report_lines.append("- " + re.sub(r"\*\*", "", s).replace("`", ""))
report_bytes = ("\n".join(report_lines)).encode("utf-8")
st.download_button("Download text story report", report_bytes, "data_story_report.txt", "text/plain")

st.caption("Built with Python, Streamlit, Pandas, NumPy, and Plotly.")
