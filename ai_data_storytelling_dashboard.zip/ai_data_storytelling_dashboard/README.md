# AI Data Storytelling Dashboard

An interactive Python dashboard that turns tabular data into charts and automatically generated, data-backed explanations.

## Features
- Use the included sample sales dataset or upload your own CSV.
- Automatically detects numeric, categorical, and date columns.
- KPI cards: total, average, median, valid record count.
- Category comparisons, distributions, monthly trends, and box plots.
- Numeric correlation heatmap.
- Rule-based data storytelling (no API key needed).
- Missing-value count and potential-outlier explorer.
- Download filtered data, KPI summary, outliers, and a text report.

## Requirements
- Python 3.10 or newer
- Internet access for the initial package installation

## Setup

### 1. Extract the project ZIP
Open a terminal in the extracted `ai_data_storytelling_dashboard` folder.

### 2. Create a virtual environment (recommended)

Windows:
```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS / Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the dashboard
```bash
streamlit run app.py
```
Streamlit prints a local URL, usually `http://localhost:8501`. Open it in your browser.

## Use your own data
1. Choose **Upload a CSV** in the sidebar.
2. Upload a `.csv` file with a header row.
3. Select the numeric measure, category, and date field.
4. Use the sidebar filters to narrow the data.

For best results, use clear column names, numeric values in numeric columns, and parseable dates (for example `2026-01-31`). The dashboard works with many CSV schemas, but at least one numeric column is needed for metric-based charts.

## Project structure
```text
ai_data_storytelling_dashboard/
├── app.py
├── requirements.txt
├── README.md
└── data/
    └── sample_sales.csv
```

## Notes / limitations
- The generated story uses transparent statistical rules. It is AI-style automated insight generation, not a call to a hosted generative-AI model.
- Correlation does not establish causation.
- Potential outliers should be reviewed, not automatically deleted.
- Very large CSV files may require optimization for performance.
